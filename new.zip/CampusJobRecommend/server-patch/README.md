# 更新 AI 面试功能

本次同时更新鸿蒙客户端和 Node AI 接口：进入面试页后，根据第一模块已提交的真实简历自动确定练习方向并出题，逐题返回评分、得分理由、改进建议和优化回答。不再选择或加载服务器岗位列表；简历提交不受质量或分析成败限制，客户端不展示具体模型名称。已提交的空白或极短简历也可以面试，先问自我介绍、沟通、学习和日常经历，不要求重新提交。

**请先阅读：**

- 新客户端必须配套部署本目录的 `server.js`。旧评分接口缺少 `improvedAnswer` 等字段时，新客户端会明确报错，不会编造结果。
- 只更新 `/opt/campus-match-web/campus-job-web/server.js`，只重启 `campus_match_web`。不要改动 `/root/campus_server`、Django 的 8000 端口、数据库或 `/opt/pinglu-canal`。
- 沿用服务器已有的 `/tmp/campus-ai.env`，不需要把密钥重新发到聊天中，也不要放入 App 或压缩包。
- 本次代码通过本地编译和模拟网关检查，**尚未部署到你的服务器，也没有进行本次线上模型实测**。
- 本目录适用于当前 Node 服务。本次不要用项目中旧的 `deepseek-server` 目录替换现有服务。
- 即使部署过 2026-10-24 的前一版面试服务，也要更新本次 `server.js`：本次版本标记为 `20261024-adaptive-1`，增加按简历信息量调整题型。只更新 App 不会更新服务器。
- 本次检查公网 `/api/interview/questions` 时，旧服务仍只返回 `aiEnabled` 和 `model`，没有新版本标记。这说明公网入口尚未提供配套新接口；不能据此判断模型本身不可用。

## 1. 上传文件，先检查再替换

把本目录的 `server.js` 上传到服务器的 `/tmp/campus-interview-server.js`，先不要覆盖运行中的文件。

在服务器终端执行：

```bash
cd /opt/campus-match-web/campus-job-web
test -s /tmp/campus-interview-server.js &&
test -s /tmp/campus-ai.env &&
node --check /tmp/campus-interview-server.js &&
node -e 'if (typeof fetch !== "function") { console.error("当前 Node 不支持全局 fetch"); process.exit(1); }'
```

以上命令应正常结束；若有报错，先不要继续。若你另外修改过服务器代码，应先合并自己的改动，不能直接覆盖。

确认检查通过后，备份并替换：

```bash
cd /opt/campus-match-web/campus-job-web
backup="server.js.before-interview-$(date +%Y%m%d-%H%M%S)"
cp -p -- server.js "$backup" &&
cp -- /tmp/campus-interview-server.js server.js &&
printf '已备份到：%s\n' "$backup"
```

记住输出的备份文件名，回滚会用到。

## 2. 仅重启 AI 所在的 Node 服务

先确认现有配置可用。命令不会打印密钥：

```bash
set -a
. /tmp/campus-ai.env
set +a
node -e 'if (!process.env.AI_API_KEY || !process.env.AI_API_URL || !process.env.AI_MODEL) { console.error("AI 环境变量不完整，请先检查配置文件"); process.exit(1); } console.log("AI 环境变量已就绪，密钥未显示");'
```

这一步正常后，在**同一个终端**执行：

```bash
cd /opt/campus-match-web/campus-job-web
export PORT=4173
screen -S campus_match_web -X quit
screen -dmS campus_match_web bash -c 'cd /opt/campus-match-web/campus-job-web && exec node server.js >> /tmp/campus_match_web.log 2>&1'
```

如果第一条 `screen` 命令提示没有该会话，表示旧会话没有运行，可以继续启动下一条。不要用 `pkill node` 或 `killall node`，否则会影响别的服务。

原配置继续生效：

| 变量 | 用途 |
| --- | --- |
| `AI_API_URL` | 完整模型 API 地址，当前为 `https://business.starway.lol/v1/chat/completions`，不是域名首页 |
| `AI_API_KEY` | 仅保存在服务器；本次不改变、不显示 |
| `AI_MODEL` | 使用你在平台配置的 `gpt-6.1-sol`；代码不将它声明为任何厂商的官方型号 |
| `AI_TIMEOUT_MS` | 可选，默认 90000 毫秒，允许范围为 1000–110000 毫秒 |
| `DJANGO_API_URL` | 保持原值；未设置时为 `http://127.0.0.1:8000/api/jobs/` |

不要关闭 Django 的 `django_campus` 会话，也不用重新执行 Django 部署。

## 3. 先只确认配置，模型测试可以以后做

以下 GET 请求不调用模型：

```bash
curl --fail --silent --show-error http://127.0.0.1:4173/api/health
curl --fail --silent --show-error http://127.0.0.1:4173/api/interview/questions
```

第二个接口应包含下列字段；接口还返回当前模型名，只供服务器检查，客户端不展示：

```json
{
  "aiEnabled": true,
  "resumeTargetEnabled": true,
  "adaptiveInterviewEnabled": true,
  "interviewApiVersion": "20261024-adaptive-1"
}
```

再检查 App 实际连接的公网入口，同样不调用模型：

```bash
curl --fail --silent --show-error http://8.148.144.213/api/interview/questions
```

**本地 4173 和公网两个结果都必须含有新版本标记。** 本地是新版而公网仍没有标记，说明公网代理未指向这个新进程，需检查现有代理目标，不要改动岗位接口。两个结果均为新版后，再启动新版 App。配置状态只能证明环境变量和接口版本，不能证明模型推理成功。

App 的 AI 后端基础地址仍是 `http://8.148.144.213`，岗位数据仍从原来的 `http://8.148.144.213:8000/api/jobs/` 获取。本次没有擅自切换公网端口或修改 Nginx。

以后准备测试时，再在第一模块提交真实简历并进入面试页。进入后会自动请求定岗与出题，不再等待选岗或开始确认，可能产生平台费用。成功后直接显示第一个问题；失败后显示重试入口，不会自动反复请求。

若使用 Nginx 代理，且日志显示网关在模型尚未结束时超时，请先检查现有 `/api/` 代理的读取超时。Node 默认允许模型运行 90 秒，App 的读取超时为 120 秒；代理不能先于 Node 中断请求。不要为此改动岗位接口。

## 4. 在 DevEco Studio 运行客户端

1. 解压完整源码包，用 DevEco Studio 打开 `CampusJobRecommend` 文件夹。
2. 等待项目同步，使用项目配置的 HarmonyOS `6.1.1(24)` SDK。
3. 真机运行前在工程签名设置中配置自己的调试签名。提供的 HAP 是**未签名构建产物**，不能当作已签名安装包直接安装。
4. 第一模块选择文件后可以直接提交，不必等 AI 分析成功。提交之后，首页才允许进入 AI 面试；进入即自动定岗和出题，不提供选岗、上传或修改简历入口。

## 简历接收与分析

- 简历内容少、质量低、没有实习经历、没有读取到正文，都不阻止提交。接收文件与 AI 分析是独立状态。
- 自动提取 DOCX、文字型 PDF、TXT 正文。扫描 PDF、旧版二进制 DOC 或其他格式仍可提交；无法读取正文时允许补充文本，不用虚假资料代替。
- 本次客户端最多自动读取 20 MiB 文件，最多发送前 30000 字符；这是读取限制，不是提交门槛。
- 非空正文才请求 `/api/resume/analyze`。如果没有正文，接口不会伪造分析；面试以“综合面试”开始，通过常规问题了解意向和真实经历，不假造岗位。无法分析正文不等于不允许面试。
- 不显示进度百分比、置信度、审核通过状态或具体模型名称。页面的 AI 建议全部来自后端实际返回，不提供本地假分析。
- 导出继续通过系统文件保存器，支持 PDF、Word 兼容的 HTML `.doc` 和 TXT；不是二进制 DOC 或 DOCX。姓名和联系方式仅从本地已识别的真实字段补回导出文本，不通过模型编造。

## 面试流程和接口

| 接口 | 行为 |
| --- | --- |
| `GET /api/interview/questions` | 返回配置状态、两个能力标记和版本号，不进行推理 |
| `POST /api/interview/questions` | 新客户端传 `targetFromResume: true`；一次请求返回面试方向、题目和 `interviewPlan` |
| `POST /api/interview/evaluate` | 返回真实模型评分、理由、亮点、缺失要点、改进方法和优化回答 |
| `POST /api/resume/analyze` | 保留原有真实模型简历分析与优化接口 |
| `POST /api/interview/respond` | 保留旧网页反馈接口；模型失败时明确报错，不降级成本地假回答 |
| `GET /api/jobs/` | 保留原有 Django 岗位代理 |

- 客户端自动生成 5 题，不再要求选择练习重点或数量；服务器仍允许 1–20 题。出题接口同时最多处理 2 个请求，每分钟最多受理 20 次。
- 有明确求职意向时采用该意向；未明确时根据真实技能、专业和经历建议方向，并标注这是建议；信息不足时使用“综合面试”。
- 信息量只决定题型分配，不作为接收、合格或评分门槛。去除空白和脱敏占位符后，正文不足 120 字符时 5 题全部为常规题；120–499 字符时至少 4 题常规题、最多 1 题基础专业题；500 字符及以上仍至少 2 题常规题。没有实际专业依据时可以全部问常规题。正文为空时以已有专业、技能、经历和求职意向字段估算。
- 常规题覆盖自我介绍、求职动机、沟通协作、学习成长和问题解决，可以使用学校、社团和生活事例。模型不得把技术考题伪装成常规题，也不得因简历短而拒绝出题。
- `targetJob` 返回 `title`、`description`、`reason`、`source`。来源分别为 `resume_explicit`、`resume_inferred` 或 `clarification`；其中的要求仅供面试练习，不是服务器里的真实招聘广告。
- 评分继续使用本次返回的方向和参考要求，不会切回某个手动选择的岗位。原有手动岗位出题请求形状保留兼容，但新客户端不使用它。
- JSON 请求体上限为 192 KiB；简历原文最多 30000 字符，岗位要求最多 5000 字符，回答最多 6000 字符。
- 不传 `temperature`、`max_tokens`、`response_format` 等可选参数，沿用网关已验证的 `{model, messages}` 请求形状。
- 得分计算公开：理解与要点 20%、内容深度 40%、事实论据 20%、表达逻辑 20%。四个维度由模型给分，服务器负责加权；不按字数或关键词命中率代替模型。常规题不因缺少技术术语、实习或专业项目扣分，可以使用真实校园或生活经历作答。
- 逐题反馈一直保留，点击“下一题”才推进；评分失败时保留回答供重试。
- 最后显示逐题得分的算术平均和每题完整复盘。结果保留在原来的 App 进程内状态管理器中，本次没有新增服务器历史记录或跨重启持久化。
- 优化示例中的 `【待补充】` 需要填写真实事实，不能当作已经发生的经历。

## 失败时看什么

| 错误码 | 含义与下一步 |
| --- | --- |
| `AI_NOT_CONFIGURED` | 配置缺失或运行时不支持 `fetch`；检查启动环境 |
| `AI_AUTH_FAILED` | 网关返回 401/403；检查服务器密钥与模型权限 |
| `AI_RATE_LIMITED` | 网关限流；稍后再试 |
| `AI_HTML_RESPONSE` | 配置地址返回网页；检查完整 API 路径 |
| `AI_UPSTREAM_FAILED` | 网关返回其他失败状态；检查平台渠道与日志 |
| `AI_CONNECTION_FAILED` | Node 连接网关失败；检查服务器网络 |
| `AI_TIMEOUT` | 模型请求超时；稍后重试或减少题数 |
| `AI_INCOMPLETE_RESPONSE` | 模型输出被截断或未正常结束；减少题数后重试 |
| `AI_INVALID_SCORE` / `AI_INVALID_EVALUATION` | 模型没有按约定返回评分或建议；本次不会生成假分数 |
| `AI_INVALID_TARGET` | 模型没有正确返回面试方向及来源；不使用本地猜测替代，请重试 |
| `AI_QUESTION_BALANCE` | 模型没有遵守本次常规题与专业题配比；不会用本地假题替换，请重试 |
| `INVALID_MODEL_RESPONSE` | 返回内容无法解析为预期结果；保留错误并重试 |

新版客户端会在出题前读取接口版本。若提示“服务器仍是旧版”，更新并重启上述 Node 服务即可，不需要为了简历字数重新上传。真实网络、鉴权、限流或模型格式错误仍会如实显示，不能用假题掩盖。

查看最近日志：

```bash
tail -n 80 /tmp/campus_match_web.log
```

不要把密钥、完整简历或包含敏感信息的日志截图公开发送。

## 回滚

先找到第 1 步生成的备份：

```bash
cd /opt/campus-match-web/campus-job-web
ls -lt server.js.before-interview-*
```

把需要恢复的备份完整文件名输入下面的提示：

```bash
read -r -p '输入要恢复的备份文件名：' backup
case "$backup" in
  server.js.before-interview-*) test -f "$backup" && node --check < "$backup" && cp -- "$backup" server.js ;;
  *) printf '文件名不符合本次备份规则，未恢复。\n' ;;
esac
```

恢复成功后，按第 2 步加载原环境并重启**同一个** `campus_match_web` 会话。若回退旧服务，客户端也需要回到兼容版本。

## 隐私与上线边界

现在会发送必要的简历原文，而不是只传可能丢失上下文的解析字段。客户端尽量隐藏已知姓名、电话、邮箱，服务器再次处理常见邮箱和手机号；这**不是保证完全匿名**。原文、岗位要求和回答会进入你配置的模型服务。

当前 App 默认公网入口仍为 HTTP，本次为避免影响现有部署没有擅自切换。正式上线前需要配置 HTTPS、认证和按用户限流；现有出题限流不等于完整的接口访问控制。
