# DeepSeek 面试出题接入版

这是基于原始 `0903 (2).zip` 完整项目合并的版本。原项目中的岗位页面、岗位接口、服务器地址、依赖、IDE 配置和构建缓存均保留；只加入或替换 AI 面试相关文件。

## 先部署服务器补丁

你的公网网站已配置 `deepseek-v4.1-flash`，但原来的服务器只有“面试回答反馈”接口，没有“按简历生成题目”接口。项目内附有 `server-patch/server.js`：它保留原网页与岗位路由，并新增 `POST /api/interview/questions`，复用服务器现有的 `AI_API_URL`、`AI_API_KEY`、`AI_MODEL` 环境变量。

部署前先备份服务器现有 `server.js`，再按 [`server-patch/README.md`](./server-patch/README.md) 更新并重启 Web 服务。未部署补丁前，App 会显示出题接口未就绪，不能仅凭“模型已配置”误报为已连通。

## 本次变更

- 面试页复用原服务器岗位接口展示并选择真实岗位，将岗位描述/要求与脱敏简历一并发送至模型。
- 服务器补丁复用 Web 服务已有的 `AI_API_URL`、`AI_API_KEY`、`AI_MODEL` 配置。
- 已确认服务器返回的模型名称为 `deepseek-v4.1-flash`；API Key 只由服务器读取，不写入 ArkTS、项目配置或安装包。
- App 默认访问现有网站 `http://8.148.144.213`；它不会把模拟器自身的 `127.0.0.1` 当成服务器。
- App 在生成题目之前会检查服务器出题接口；服务器端未部署新增路由时不会显示“已连接”或误用本地题库。
- 新增上传后真实 AI 简历分析、优化建议与 AI 优化稿导出。
- AI 面试在没有上传简历时锁定；题目和评分均请求服务器模型，评分展示理由与改进建议；请求失败时不伪装成 AI 评分。
- 简历分析发送学校、专业、学历、技能、经历和求职意向，不发送姓名、电话、邮箱或原始全文。
- 岗位信息仍从原来的服务器接口加载，本次没有修改岗位数据代码。

## 新增功能服务器部署

本次还需将 `server-patch/server.js` 合并到当前 Web 服务并重启，部署指南已更新在 `server-patch/README.md`。新增接口为 `POST /api/resume/analyze` 和 `POST /api/interview/evaluate`，仍只读取服务器现有 `AI_API_URL`、`AI_API_KEY`、`AI_MODEL`，密钥绝不写入客户端。若服务器部署了更新版 `server.js`，先备份并按指南合并，勿覆盖其岗位代理配置。

简历导出当前使用系统文件保存器保存 `.txt` 优化稿；不会伪称导出 PDF/Word。公网简历接口目前使用 HTTP，生产环境应先启用 HTTPS。

## 使用服务器上的 DeepSeek

更新服务器端后，在 App 的 AI 面试页点击“DeepSeek 生成专属面试题”。如服务器地址不同，可在“修改服务器地址”里修改。不要填写 DeepSeek 模型网关地址或 API Key；模型密钥只在服务器使用。

## 本地独立出题服务（可选）

以下是本地调试或没有现成网站服务时使用的独立 Node 服务。使用现有公网服务器时不需要在模拟器里启动 `127.0.0.1:8787`。

### Windows 快速启动

需要 Node.js 20 或更高版本。

```powershell
cd .\deepseek-server
.\start.ps1 -BindAddress 127.0.0.1 -Port 8787
```

脚本会安全提示输入新的 API Key，不会把密钥保存到文件。客户端与服务处于同一网络地址空间时，可在应用的“修改服务器地址”区域填写：

```text
http://127.0.0.1:8787
```

如果应用运行在真机、模拟器或另一台电脑上，`127.0.0.1` 指向设备自身，不能代替服务电脑地址。请把服务绑定到可信局域网地址，并填写设备能够访问的服务电脑局域网 IP：

```powershell
.\start.ps1 -BindAddress 0.0.0.0 -Port 8787
```

不要把这个未加入登录鉴权的开发服务直接暴露到公网。

## 本地独立出题服务配置

以下环境变量只用于可选的本地独立服务 `deepseek-server`。使用现有 Web 服务器时，由服务器自身的 `AI_API_*` 环境变量配置模型。

| 环境变量 | 默认值 | 说明 |
| --- | --- | --- |
| `DEEPSEEK_API_KEY` | 无 | 仅独立服务端使用的 API Key |
| `DEEPSEEK_API_URL` | `https://business.starway.lol/v1/chat/completions` | DeepSeek 兼容 Chat Completions 地址 |
| `DEEPSEEK_MODEL` | `deepseek-v4.1-flash` | 出题模型 |
| `HOST` | `127.0.0.1` | 服务监听地址 |
| `PORT` | `8787` | 服务监听端口 |

Linux 或服务器上，在项目根目录的 Bash 中通过隐藏输入读取密钥，不要把密钥写进命令历史或源码：

```bash
read -r -s -p 'API Key: ' DEEPSEEK_API_KEY
printf '\n'
export DEEPSEEK_API_KEY
export DEEPSEEK_API_URL='https://business.starway.lol/v1/chat/completions'
export DEEPSEEK_MODEL='deepseek-v4.1-flash'
HOST=127.0.0.1 PORT=8787 node deepseek-server/server.mjs
unset DEEPSEEK_API_KEY
```

## 说明

- 本包不包含聊天中公开的旧密钥，也没有使用它发起真实计费请求；建议立即在服务商后台撤销并重新生成旧密钥。
- 解压后，在 DevEco Studio 中打开 `0903/CampusJobRecommend` 项目目录，执行 Clean 后重新构建。原包附带的构建缓存和旧 HAP 仅原样保留，不是本次编译的产物。
- 本次使用 DevEco Studio 6.1.1 在临时完整副本中 `assembleHap` 编译成功；生成的是未签名 HAP。服务器路由用本地模拟模型验证通过，未发送真实计费请求，也未进行真机端到端验证。
- 本包只提供服务器更新文件，未直接修改你的公网服务器。上传服务器补丁并重启原 Web 服务后，App 才能通过服务器真实调用 DeepSeek 按简历出题。
- 生产环境还应增加 HTTPS、访问鉴权、按用户限流和日志脱敏。
