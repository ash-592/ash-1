# 更新校园岗位服务器出题接口

你的现有 Web 服务器已经配置 DeepSeek，但原服务只提供面试回答反馈接口。这个目录中的 `server.js` 在保留原网页、岗位代理、健康检查和回答反馈路由的基础上，增加了按简历生成题目、简历分析优化和面试 AI 判分接口。

## 部署前确认

该文件基于服务器当前公开的 `server.js` 制作，基线 SHA-256 为：

```text
4826e0a5a19e547ce1d44fa4c92b969ac16afd4b9435f68b18cf95c3ca976970
```

如果服务器上的 `server.js` 已经有后续改动，不要直接覆盖；应先将新增的 `/api/interview/questions` 路由合并到现有文件。

## 部署步骤

1. 先备份服务器当前的 `/opt/campus-match-web/campus-job-web/server.js`。
2. 将本目录的 `server.js` 上传并替换到上述路径。
3. 按原方式重启 `campus_match_web` Node 服务；保持原有 `AI_API_URL`、`AI_API_KEY`、`AI_MODEL` 环境变量不变。
4. 访问 `http://8.148.144.213/api/interview/questions`，应返回 `aiEnabled` 和 `model`。部署后还应按下方接口说明测试简历分析与评分路由。
5. 回到鸿蒙 App 的 AI 面试页面，点击“重试连接”，显示服务器已启用模型后即可生成简历定制题目。

这个更新不需要改 Django 岗位服务、数据库或 Nginx 配置，也不需要把 API Key 放进 App。

## 接口

- `GET /api/interview/questions`：返回模型是否已配置及模型名称，不返回密钥。
- `POST /api/interview/questions`：接收必要简历字段、岗位名称/要求和题型，返回结构化题目。
- `POST /api/resume/analyze`：接收脱敏简历字段，返回分析、优势、优化建议和优化后的简历正文。
- `POST /api/interview/evaluate`：结合简历、岗位要求、题目和回答，返回分数、理由与改进建议。
- 每次最多生成 20 道题；请求体限制为 64 KB；同时最多处理 2 个出题请求，并限制每分钟 20 次请求。
- 接口使用服务器现有的模型环境变量，不写入或记录密钥。

## 隐私

当前公网入口是 HTTP。虽然 App 不发送姓名、电话、邮箱和原始全文，技能/经历仍可能包含个人信息。上线前务必配置 HTTPS，并限制接口访问、增加身份认证与频率控制。
