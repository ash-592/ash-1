param([string]$BindAddress = '127.0.0.1', [int]$Port = 8787)
$ErrorActionPreference = 'Stop'
if (-not $env:DEEPSEEK_API_KEY) {
  $secureKey = Read-Host '请输入新的有效 DeepSeek API Key（不会回显或保存到文件）' -AsSecureString
  $keyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
  try {
    $env:DEEPSEEK_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($keyPointer)
  } finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($keyPointer)
  }
}
$env:HOST = $BindAddress
$env:PORT = $Port.ToString()
Push-Location $PSScriptRoot
try {
  node server.mjs
} finally {
  Pop-Location
  Remove-Item Env:DEEPSEEK_API_KEY -ErrorAction SilentlyContinue
}
