# DeepSeek 面试出题服务

该服务只在本地或自有服务器保存 DeepSeek 密钥，HarmonyOS 客户端不会内置密钥。客户端提交已解析的专业、学历、技能、经历和求职意向，服务端调用 DeepSeek 生成结构化面试题。

## 启动

在 PowerShell 中执行：

```powershell
cd D:\验收\0903\0903\CampusJobRecommend\deepseek-server
.\start.ps1 -BindAddress 127.0.0.1
```

首次启动会安全地提示输入新的 DeepSeek API Key，不会保存到文件。需要 Node.js 20 或更新版本，无须安装 npm 依赖。模拟器地址因运行方式而异；真机请使用电脑局域网地址，启动时绑定局域网网卡，例如：

```powershell
.\start.ps1 -BindAddress 0.0.0.0 -Port 8787
```

然后在应用的“DeepSeek 简历定制出题”输入框填写 `http://电脑局域网IP:8787`。

## 配置

| 环境变量 | 必需 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `DEEPSEEK_API_KEY` | 是 | 无 | 仅服务端使用的密钥 |
| `DEEPSEEK_MODEL` | 否 | `deepseek-flash` | 可切换为账户可用的 DeepSeek 模型 |
| `HOST` | 否 | `127.0.0.1` | 监听地址 |
| `PORT` | 否 | `8787` | 监听端口 |

## 安全约束

- 不把 API Key 写入 ArkTS、JSON、日志或安装包。
- 服务端只接收简历必要字段，不接收姓名、电话、邮箱和原始简历全文。
- 只允许 1–20 道题，限制请求体大小和并发数，并校验模型返回结构。
- 客户端仍使用现有本地规则评分；DeepSeek 负责简历定制出题，不负责最终分数。
- 你在聊天中公开的密钥已按 401 认证失败处理，请撤销并重新生成后再启动服务。
- 这是本地验收服务，没有用户登录鉴权。绑定 `0.0.0.0` 仅用于可信局域网测试，防火墙应只允许测试设备。不要直接暴露到公网；生产部署必须增加 HTTPS、登录鉴权和按用户限流。
- 经历等自由文本可能包含个人信息，请上传前自行删除；服务不记录简历和密钥，但必要字段会发送给 DeepSeek。

## 验证结果

2026-10-14：服务端格式与隐私字段过滤基础校验通过；模拟 DeepSeek 返回的 HTTP 接口测试通过。鸿蒙 `assembleHap` 构建在 `D:\HarmonyOS\DeepSeekInterview_20261014` 成功（未配置签名）。真实密钥验证返回 HTTP 401，未完成真实模型出题及真机端到端测试。

DevEco 不接受包含中文的项目路径，请直接打开 `D:\HarmonyOS\DeepSeekInterview_20261014` 作为可构建项目。原始 ZIP 未修改。
